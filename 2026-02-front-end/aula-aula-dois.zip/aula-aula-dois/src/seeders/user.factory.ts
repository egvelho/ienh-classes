import { Factory } from '@mikro-orm/seeder';
import { faker } from '@faker-js/faker';
import { User } from 'src/users/entities/user.entity';

export class UserFactory extends Factory<User> {
  model = User;
  protected definition(): Partial<User> {
    return {
      nome: faker.person.firstName(),
      sobrenome: faker.person.lastName(),
      email: faker.internet.email(),
      senha: faker.internet.password(),
    };
  }
}
