import { Entity, PrimaryKey, Property } from '@mikro-orm/decorators/legacy';

// nome, sobrenome, email, senha
@Entity({ tableName: 'users' })
export class User {
  @PrimaryKey({ type: 'int' })
  id!: number;

  @Property({ type: 'string' })
  nome!: string;

  @Property({ type: 'string' })
  sobrenome!: string;

  @Property({ type: 'string', unique: true })
  email!: string;

  @Property({ type: 'string' })
  senha!: string;
}
