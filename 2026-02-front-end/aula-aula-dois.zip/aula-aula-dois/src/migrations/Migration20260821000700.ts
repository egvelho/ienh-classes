import { Migration } from '@mikro-orm/migrations';

export class Migration20260821000700 extends Migration {

  override name = 'Migration20260821000700';

  override up(): void | Promise<void> {
    this.addSql(`alter table \`users\` add column \`senha\` text not null;`);
  }

  override down(): void | Promise<void> {
    this.addSql(`alter table \`users\` drop column \`senha\`;`);
  }

}
