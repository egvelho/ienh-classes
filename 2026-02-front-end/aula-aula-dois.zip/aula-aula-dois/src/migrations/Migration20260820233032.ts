import { Migration } from '@mikro-orm/migrations';

export class Migration20260820233032 extends Migration {

  override name = 'Migration20260820233032';

  override up(): void | Promise<void> {
    this.addSql(`create table \`users\` (\`id\` integer not null primary key autoincrement, \`nome\` text not null, \`sobrenome\` text not null, \`email\` text not null, \`senha\` text not null);`);
    this.addSql(`create unique index \`users_email_unique\` on \`users\` (\`email\`);`);
  }

  override down(): void | Promise<void> {
    this.addSql(`drop table if exists \`users\`;`);
  }

}
